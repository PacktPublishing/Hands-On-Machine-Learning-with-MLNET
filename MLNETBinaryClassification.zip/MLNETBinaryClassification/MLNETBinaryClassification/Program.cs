/* This template shows the building blocks for training a machine learning model with ML.NET (https://aka.ms/mlnet).
 * This model predicts whether a sentence has a positive or negative sentiment. It is based on a sample that can be 
 * found at https://aka.ms/mlnetsentimentanalysis, which provides a more detailed introduction to ML.NET and the scenario. */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.ML;
using Microsoft.ML.Core.Data;
using Microsoft.ML.Data;

namespace MLNETBinaryClassification
{
    public class FeedbackData
    {
        [LoadColumn(0)]
        public float FeedbackType { get; set; }

        [LoadColumn(1)]
        public string Feedback { get; set; }
    }

    // Feedback pridiction is the result returned from prediction 
    public class FeedbackPrediction
    {
        [ColumnName("PredictedLabel")]
        public bool Prediction { get; set; }

        [ColumnName("Probability")]
        public float Probability { get; set; }

      
    }

    class Program
    {
        //Set the Train Dataset Path
        static readonly string _FeedbacktrainDataPath = Path.Combine(Environment.CurrentDirectory, "Data", "Feedback-Train.csv");
        static readonly string _FeedbacktestDataPath = Path.Combine(Environment.CurrentDirectory, "Data", "Feedback-Test.csv");
        static readonly string _savedModelPath = Path.Combine(Environment.CurrentDirectory, "Data", "Model.zip");
        static TextLoader textLoader;
        static void Main()
        {
            var mlContext = new MLContext();

         textLoader = mlContext.Data.CreateTextReader(new TextLoader.Arguments()
                                    {
                                        Separator = ",",
                                        HasHeader = true,
                                        Column = new[]
                                                    {
                                                      new TextLoader.Column("FeedbackType", DataKind.Bool, 0),
                                                      new TextLoader.Column("Feedback", DataKind.Text, 1)
                                                    }
                                    }
                            );
            //Train the Model
            var model = TraintheModel(mlContext, _FeedbacktrainDataPath);

            //Evaluate the Model
            EvaluatetheModel(mlContext, model);

            //Save the Model to the ZipFile
            SavetheModeltoZipFile(mlContext, model);

            //Result Prediction
            PredictResults(mlContext, model);

            //Predict the Model with saved model.
            PredictWithModelLoadedFromFile(mlContext);
            Console.ReadLine();
        }

        //Train the Model
        public static ITransformer TraintheModel(MLContext mlContext, string TrainDataPath)
        {
            //Load the Train Dataset for training the model

            //Using the Pipeline we load the Dataset and set the MapValueToKey to Label here our label is FeedbackType.
            //Add the Feature Columns here using Transforms.Text.FeaturizeText method.
            //Here we are using the Regression Task for the Binary Classification model and used the StochasticDualCoordinateAscent algorithm 
          
            IDataView dataView = textLoader.Read(TrainDataPath);
            var pipeline = mlContext.Transforms.Text.FeaturizeText("Feedback", "Features")
                .Append(mlContext.BinaryClassification.Trainers.StochasticDualCoordinateAscent("FeedbackType", "Features"));

            Console.WriteLine("---- Step 1 :  Train the Model");
            //Train the model with our data set  
            var model = pipeline.Fit(dataView);
            Console.WriteLine("---- Train Completed");
            Console.WriteLine();

            return model;
        }

        public static void EvaluatetheModel(MLContext mlContext, ITransformer model)
        {
            //loading the test data for evaluating he model
            IDataView dataView = textLoader.Read(_FeedbacktestDataPath);
            Console.WriteLine("--------- Step 2 : Evaluate the Model with the test data ");
            //Predicting the test data with the prediction label and here our label is as FeedbackType


            var predictions = model.Transform(dataView);
            //Using BinaryClassification Evaluator method we evaluate the model with the testdata and produce evaluation metrics
            var metrics = mlContext.BinaryClassification.Evaluate(predictions, "FeedbackType");

           // We display Metric Accuracy and F1 Score.

            Console.WriteLine("----------- Step 3 Display how the metric result for our model as how accurate tht eprediction is done");
            // Metrics Accuracy is used on how accurate our model has predicted the result is 
            Console.WriteLine($"Accuracy: {metrics.Accuracy:P2}"); 
            // F1 Score is another evaluation metric where the value will be between 0 to 1. If the value is closer to 1 is the better model.
            Console.WriteLine($"F1 Score: {metrics.F1Score}");  
        }

        private static void SavetheModeltoZipFile(MLContext mlContext, ITransformer model)
        {
            Console.WriteLine("----------- Step 4 Save the Trained Model to the Zip file  ");
            //Save the Trained Model to the Zip file
            using (var fs = new FileStream(_savedModelPath, FileMode.Create, FileAccess.Write, FileShare.Write))
                mlContext.Model.Save(model, fs); 
        }

        //Predicting Results from the trained model with test dataset
        private static void PredictResults(MLContext mlContext, ITransformer model)
        {
            //Creating the prediction Function to predict the result with our Feedbackkdata and FeedbackPrediction
            var predictionFunction = model.CreatePredictionEngine<FeedbackData, FeedbackPrediction>(mlContext);
            Console.WriteLine("----------- Step 5 Enter the Customer Feedback sample to predict the result  ");
            Console.WriteLine("Enter the Cusotmer Feedback sample for prediction");
            //Enter your input to predict the result as Positive or Negative
            FeedbackData userFeedback = new FeedbackData
            {
                Feedback = Console.ReadLine()// "Not using at all"
            };
            var resultprediction = predictionFunction.Predict(userFeedback);
            Console.WriteLine("----------- Step 6 Final Predicted result witht he Probability  "); 
            Console.WriteLine($"Customer Feedback: {userFeedback.Feedback} | Prediction: {(Convert.ToBoolean(resultprediction.Prediction) ? "Customer Feedback Is Positive" : "Customer Feedback Is  Negative")} | Probability: {resultprediction.Probability} ");
         }

        //This method is used to predict the results from the Saved Trained Model .Once the model is trained we store the model in our root folder ,we can use that  trained model later for predicting other input resutls 
        public static void PredictWithModelLoadedFromFile(MLContext mlContext)
        {
            Console.WriteLine("----------- Step 7 -- This is optional as this Step we will be using our saved model for more predictions  ");
            //Give input for more prediction here we have given 2 input as one with positive feedback and one with Negative feedback ,Let see how accuratly the model is trained and predicting the results.

            IEnumerable<FeedbackData> feedbacks = new[]
                            {
                                new FeedbackData
                                {
                                    Feedback = "Suerly will continue to buy your product" //Positive Feedback
                                },
                                new FeedbackData
                                {
                                    Feedback = "Expecting next product should be good." //Negative Feedback
                                }
                            };
            ITransformer loadedModel;

            //Load the saved trained model for Prediction
            using (var stream = new FileStream(_savedModelPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                loadedModel = mlContext.Model.Load(stream);
            }

            // Create prediction engine
            var FeedbackDataView = mlContext.CreateStreamingDataView(feedbacks);
            var predictions = loadedModel.Transform(FeedbackDataView);

            // Use the model to predict whether comment data is toxic (1) or nice (0).
            var predictedResults = predictions.AsEnumerable<FeedbackPrediction>(mlContext, reuseRowObject: false);

            
            Console.WriteLine("----------- Step 8 - Predicting the results with looping for more than oen item prediction.-");

            var feedbackAndPredictions = feedbacks.Zip(predictedResults, (Feedback, prediction) => (Feedback, prediction));
            //For more than 1 item prediction using the loop we predict the result one by one
            foreach (var item in feedbackAndPredictions)
            {
                Console.WriteLine($"Feedback: {item.Feedback.Feedback} | Prediction: {(Convert.ToBoolean(item.prediction.Prediction) ? "Customer Feedback Is Positive" : "Customer Feedback Is Negative")} | Probability: {item.prediction.Probability} ");
            }
           
        }

    }

    
}
