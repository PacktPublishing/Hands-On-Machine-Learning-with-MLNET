﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MLNETRegressionModel
{
   static class HouseData
    {
        internal static readonly classHouse houseDatas1 = new classHouse
        {
            CityName = "Madurai",// "Enter the City Name"
            AreaName = "AnnanNagar 1stStreet",
            HouseType = "Apartment",
            FloorDetails = "4thFloor",
            NoofRooms = 2,
            HouseRent = 0 // This we will get from our Prediction Output. Actual = 16000
        };

        internal static readonly classHouse houseDatas2 = new classHouse
        {
            CityName = "Madurai",// "Enter the City Name"
            AreaName = "KKNagar 2ndStreet",
            HouseType = "Individual",
            FloorDetails = "1stFloor",
            NoofRooms = 3,
            HouseRent = 0 // This we will get from our Prediction Output. Actual = 20000
        };
    }
}
