/* This template shows the building blocks for training a machine learning model with ML.NET (https://aka.ms/mlnet).
 * This model predicts whether a sentence has a positive or negative sentiment. It is based on a sample that can be 
 * found at https://aka.ms/mlnetsentimentanalysis, which provides a more detailed introduction to ML.NET and the scenario. */

using System;
using System.IO;
using Microsoft.ML;
using Microsoft.ML.Core.Data;
using Microsoft.ML.Data;

namespace MLNETRegressionModel
{
    class Program
    {
        //Set the Train Dataset Path
        static readonly string _HouseRenttrainDataPath = Path.Combine(Environment.CurrentDirectory, "Data", "HouseRent-Train.csv");
        static readonly string _HouseRenttestDataPath = Path.Combine(Environment.CurrentDirectory, "Data", "HouseRent-Test.csv");
        static readonly string _savedModelPath = Path.Combine(Environment.CurrentDirectory, "Data", "Model.zip");

        static TextLoader textLoader;
        static void Main()
        {
            var mlContext = new MLContext();

            textLoader = mlContext.Data.CreateTextReader(new TextLoader.Arguments()
            {
                Separator = ",",
                HasHeader = true,
                Column = new[]
                                                       {
                                                      new TextLoader.Column("CityName", DataKind.Text, 0),
                                                      new TextLoader.Column("AreaName", DataKind.Text, 1),
                                                       new TextLoader.Column("HouseType", DataKind.Text, 2),
                                                        new TextLoader.Column("FloorDetails", DataKind.Text, 3),
                                                         new TextLoader.Column("NoofRooms", DataKind.R4, 4),
                                                          new TextLoader.Column("HouseRent", DataKind.R4, 5)
                                                    }
            }
                               );
            //Train the Model
            var model = TraintheModel(mlContext, _HouseRenttrainDataPath);

            //Evaluate the Model
            EvaluatetheModel(mlContext, model);

            //Save the Model to the ZipFile
            SavetheModeltoZipFile(mlContext, model);

            //Result Prediction
            //Result Prediction
            

          


            var predictionFunction = model.CreatePredictionEngine<classHouse, HouseRentPrediction>(mlContext);
            Console.WriteLine("----------- Step 5 Enter the House Details with out the House rent to predict the result  ");
            Console.WriteLine("Enter the House Details sample for prediction");
            //Enter your input to predict the result as Positive or Negative

            Console.WriteLine("----------- Step 6 Final Predicted result witht he Probability  ");
            var resultprediction = predictionFunction.Predict(HouseData.houseDatas1);
            Console.WriteLine("----------- First Prediction Results Output ");
            Console.WriteLine($"Actual Rent is : 16000 | Prediction Result :   {resultprediction.HouseRent:#}");

            var resultprediction2 = predictionFunction.Predict(HouseData.houseDatas2);
            Console.WriteLine("----------- Second Prediction Results Output ");
            Console.WriteLine($"Actual Rent is : : 20000| Prediction Result :   {resultprediction2.HouseRent:#}");

            Console.WriteLine("----------- Input given by User ");

            string cityNames = "", AreaNames = "", HouseTypes = "", FloorDetailss = ""; 
                float NoofRoomss = 0, ActualHouseRent=0;

            Console.WriteLine("-------Enter City Name --- ");
            cityNames = Console.ReadLine();

            Console.WriteLine("-------Enter AreaNames Name --- ");
            AreaNames = Console.ReadLine();

            Console.WriteLine("-------Enter House Types --- ");
            HouseTypes = Console.ReadLine();

            Console.WriteLine("-------Enter Floor Detailss --- ");
            FloorDetailss = Console.ReadLine();

            Console.WriteLine("-------Enter No of Roomss (** Only Numbers) --- ");
            NoofRoomss = Convert.ToInt32( Console.ReadLine());

            Console.WriteLine("-------Enter Actual House Rent  (** Only Numbers) --- ");
            ActualHouseRent = Convert.ToInt32(Console.ReadLine());

            classHouse houseData = new classHouse
            {

                CityName = cityNames,// "Enter the City Name"
                AreaName = AreaNames,
                HouseType = HouseTypes,
                FloorDetails = FloorDetailss,
                NoofRooms = NoofRoomss,
                HouseRent = ActualHouseRent // 
            };

            var resultprediction3 = predictionFunction.Predict(houseData);
            Console.WriteLine("----------- Second Prediction Results Output ");
            Console.WriteLine($"Actual Rent is : : {ActualHouseRent}| Prediction Result :   {resultprediction3.HouseRent:#}");


            Console.ReadLine();
        }


        //Train the Model
        public static ITransformer TraintheModel(MLContext mlContext, string TrainDataPath)
        {
            //Load the Train Dataset for training the model

            //Using the Pipeline we load the Dataset and set the MapValueToKey to Label here our label is HouseRent.
            //In ML.NET the input need to be only in the Numerical  for this all our text input we need to convert to ML.NET numarical using the mlContext.Transforms.Categorical.OneHotEncoding method. 
            //Add the Feature Columns here using (mlContext.Transforms.Concatenate method.
            //Here we are using the Regression Task using FastTree Algorithm for training the model for prediccting the House rent  

            IDataView dataView = textLoader.Read(TrainDataPath);
             var pipeline = mlContext.Transforms.CopyColumns("HouseRent", "Label")
                .Append(mlContext.Transforms.Categorical.OneHotEncoding("CityName"))
                .Append(mlContext.Transforms.Categorical.OneHotEncoding("AreaName"))
                .Append(mlContext.Transforms.Categorical.OneHotEncoding("HouseType"))
                 .Append(mlContext.Transforms.Categorical.OneHotEncoding("FloorDetails"))
                .Append(mlContext.Transforms.Concatenate("Features", "CityName", "AreaName", "HouseType", "FloorDetails", "NoofRooms"))
                .Append(mlContext.Regression.Trainers.FastTree());


            Console.WriteLine("---- Step 1 :  Train the Model");
            //Train the model with our data set  
            var model = pipeline.Fit(dataView);
            Console.WriteLine("---- Train Completed");
            Console.WriteLine();

            return model;
        }


        public static void EvaluatetheModel(MLContext mlContext, ITransformer model)
        {
            //loading the test data for evaluating he model
            IDataView dataView = textLoader.Read(_HouseRenttestDataPath);
            Console.WriteLine("--------- Step 2 : Evaluate the Model with the test data ");
            //Predicting the test data with the prediction label and here our label is as FeedbackType 
            var predictions = model.Transform(dataView);
            //Using BinaryClassification Evaluator method we evaluate the model with the testdata and produce evaluation metrics
            var metrics = mlContext.Regression.Evaluate(predictions, "HouseRent", "Score");

            //             We display both the RMS(Root mean Squared) and RSquared metrics value. 

            Console.WriteLine("----------- Step 3 Display how the metric result for our model with RSuared and RMS result");

            // RMS is one of evaluation metrics where the lower RMS value is treated as the better model.
            Console.WriteLine($"Rms = {metrics.Rms}");
            //  RSquared is another evaluation metric where the value will be between 0 to 1.If the value is closer to 1 is the better model.
            Console.WriteLine($"RSquared = {metrics.RSquared}");
           
        }


        private static void SavetheModeltoZipFile(MLContext mlContext, ITransformer model)
        {
            Console.WriteLine("----------- Step 4 Save the Trained Model to the Zip file  ");
            //Save the Trained Model to the Zip file
            using (var fs = new FileStream(_savedModelPath, FileMode.Create, FileAccess.Write, FileShare.Write))
                mlContext.Model.Save(model, fs);
        }

        //Predicting Results from the trained model with test dataset
        private static void PredictResults(MLContext mlContext, ITransformer model)
        {
            //Creating the prediction Function to predict the result with our Feedbackkdata and FeedbackPrediction
            var predictionFunction = model.CreatePredictionEngine<classHouse, HouseRentPrediction>(mlContext);
            Console.WriteLine("----------- Step 5 Enter the House Details with out the House rent to predict the result  ");
            Console.WriteLine("Enter the House Details sample for prediction");
            //Enter your input to predict the result as Positive or Negative
            classHouse houseData = new classHouse
            {
                CityName = "Madurai",// "Enter the City Name"
                AreaName = "AnnanNagar 1stStreet",
                HouseType = "Apartment",
                FloorDetails = "6thFloor",
                NoofRooms= 3,
                HouseRent= 0 // This we will get from our Prediction Output. Actual = 24000
            };
            var resultprediction = predictionFunction.Predict(houseData);
            Console.WriteLine("----------- Step 6 Final Predicted result witht he Probability  ");
            Console.WriteLine($"Actual Rent is : 19000 | Prediction Result :   {resultprediction.HouseRent:#}");
        }



    }


}
