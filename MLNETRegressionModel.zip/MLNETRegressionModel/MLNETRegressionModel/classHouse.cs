﻿using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Text; 

namespace MLNETRegressionModel
{
    class classHouse
    {
        [LoadColumn(0)]
        public string CityName { get; set; }

        [LoadColumn(1)]
        public string AreaName { get; set; }

        [LoadColumn(2)]
        public string HouseType { get; set; }

        [LoadColumn(3)]
        public string FloorDetails { get; set; }

        [LoadColumn(4)]
        public float NoofRooms { get; set; }

        [LoadColumn(5)]
        public float HouseRent { get; set; } 

    }

    public class HouseRentPrediction
    {
        [ColumnName("Score")]
        public float HouseRent { get; set; }
    }
}
