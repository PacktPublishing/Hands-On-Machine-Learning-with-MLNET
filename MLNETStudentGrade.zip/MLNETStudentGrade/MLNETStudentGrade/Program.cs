﻿using Microsoft.ML;
using Microsoft.ML.Legacy;
using Microsoft.ML.Legacy.Trainers;
using Microsoft.ML.Legacy.Transforms;
using Microsoft.ML.Runtime.Data;


using Microsoft.ML.Runtime.Api;
using System;
using System.IO;

namespace MLNETStudentGrade
{
    class Program
    {
        public class GradeData
        {
            public float Marks;
            public float Attendance; 
            public string Grade;
        }

        // Grade pridiction is the result returned from prediction 
        public class GradePrediction
        {
            [ColumnName("PredictedLabel")]
            public string Grade;
        }
        static void Main(string[] args)
        {
            var mlContext = new MLContext();

           //Set the Train Dataset Path
            string csvdataPath = Path.Combine(Environment.CurrentDirectory, "Data", "GradeTrain.csv");
          //  Set the Columns which we need to 
            var reader = mlContext.Data.TextReader(new TextLoader.Arguments()
            {
                Separator = ",",
                HasHeader = true,
                Column = new[]
                {
                    new TextLoader.Column("Marks", DataKind.R4, 0),
                    new TextLoader.Column("Attendance", DataKind.R4, 1),
                    new TextLoader.Column("Grade", DataKind.Text, 2), 
                }
            });

            //Load the Data
            IDataView trainingDataView = reader.Read(new MultiFileSource(csvdataPath));

            //Using the Pipeline we load the Dataset and set the MapValueToKey to Label here our label is Grade.
            //Add the Feature Columns here using Transforms.Concatenate method.
            //Here we are using the Regression Task Multiclass Classification model and used the StochasticDualCoordinateAscent algorithm to
            // predict the results and added the Grade as the Label column as we need to predict the result for the grade.
            // Finally using the Transforms.Conversion set the Predicted Label for prediction.

            var pipeline = mlContext.Transforms.Categorical.MapValueToKey("Grade")
                .Append(mlContext.Transforms.Concatenate("Features", "Marks", "Attendance"))
                .Append(mlContext.MulticlassClassification.Trainers.StochasticDualCoordinateAscent(label: "Grade", features: "Features"))
                .Append(mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));

            //Train the model with our data set  
            var model = pipeline.Fit(trainingDataView);

            //Using our model to predict the results and here we can note that as we are going to predict
            // the results for the Marks % 98 and Attendance % is 94 and here we didn’t give the grade
            //data as our model will predict based on our input and display the predicted result for us output.
            // You can change these numbers to test different predictions.

            var prediction = model.MakePredictionFunction<GradeData, GradePrediction>(mlContext).Predict(
                new GradeData()
                {
                    Marks = 98f,
                    Attendance = 94f, 
                });

            // Now we display the final Predicted results using our prediction object which we get using the MakePredictionFunction 
            Console.WriteLine("-------Student Grade Prediction Result : ----------------"); 
            Console.WriteLine("Marks 98% and Attendance 94%");
            Console.WriteLine("Predicted Student Grade is :  {0}", prediction.Grade);
            Console.WriteLine(" ");
            
          

            Console.ReadLine();
        }
    }
}
